function out = dotsim(day_shift, delta, base_freq, sigma_strain, sigma_auxchan, nbinpersec, value, ncycles, coupling, halfwidth, bandpassquerey)

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% INITIALIZE AUXDATA %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    nbintot = nbinpersec*8;
    auxchan_data = random('norm',0.,sigma_auxchan,nbintot,1);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%NEAR-INTEGER COMB CHAN1%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    nbinsperday = nbinpersec*60*60*24;
    nbinspercycle = nbinpersec*8;

    freq = delta + base_freq;
    binsperiod = round(nbinpersec/freq); %how many bins pass for each frequency cycle

    binsperiodcounter = mod(nbinsperday*day_shift,binsperiod) + 1;
    cyclecounter = 1;
    halfwidth = round(halfwidth*nbinpersec);

    while cyclecounter < ncycles + 1
        bincounter = 1;
        while bincounter < (nbinspercycle + 1)
            if binsperiodcounter/binsperiod == 1
                height = value/ncycles;
                centerindex = bincounter;
                auxchan_data = peakmaker(auxchan_data, halfwidth, height, centerindex);% auxchan_data(bincounter) + value/ncycles;
                binsperiodcounter = 1;
            else
                binsperiodcounter = binsperiodcounter + 1;
            end
            bincounter = bincounter + 1;
        end
        cyclecounter = cyclecounter + 1;
    end    

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CREATE & CONTAMINATE THE STRAIN CHANNEL %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    strain_data_pure = random('norm',0.,sigma_strain,nbintot,1);
    strain_data = strain_data_pure;

    strain_data = strain_data + auxchan_data*coupling;
    mean_strain = mean(strain_data);
    std_strain = std(strain_data);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% BANDPASS 10-50 HZ %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    if bandpassquerey
        
        auxchan_data = bandpass(auxchan_data,[10,50],nbinpersec);
        strain_data = bandpass(strain_data,[10,50],nbinpersec);
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CALCULATE DOTPRODUCT %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    mean_auxchan = mean(auxchan_data);
    std_auxchan = std(auxchan_data);
    
    dotprodterms = 1:nbintot;
    dotprodterms(:) = (strain_data-mean_strain).*(auxchan_data(:)-mean_auxchan)/(sqrt(nbintot)*std_strain*std_auxchan);
    out = dotprodterms;
end